# Define the Policyholder class to manage individual insurance customers
class Policyholder:
    def __init__(self, name, policy_id):
        """
        Initialize a policyholder with a name and unique policy ID.

        Args:
            name (str): Name of the policyholder.
            policy_id (str): Unique identifier for the policyholder.
        """

        self.name = name
        self.policy_id = policy_id
        self.status = "Active"  # Initial status is active
        self.policies = []     # List to store the policyholder's insurance products
        self.payments = []     # List to store payment records

# Suspend the policyholder (e.g., due to missed payment or policy breach)
    def suspend(self):
        self.status = "Suspended"

# Reactivate a previously suspended policyholder
    def reactivate(self):
        self.status = "Active"

# Assign an insurance product to the policyholder
    def add_policy(self, product):
        self.policies.append(product)

# Add a payment record to the policyholder
    def add_payment(self, payment):
        self.payments.append(payment)

    def get_details(self):

        # Returns a dictionary containing the policyholder's information, including products and payments.
        return {
            'Name': self.name,
            'ID': self.policy_id,
            'Status': self.status,
            'Policies': [p.product_name for p in self.policies],
            'Payments': [p.amount for p in self.payments]
        }
