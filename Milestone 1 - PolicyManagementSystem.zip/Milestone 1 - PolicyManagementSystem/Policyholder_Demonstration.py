from datetime import date               # Used to get today's date for payment
from payment import Payment             # Import Payment class
from product import Product             # Import Product class
from policyholder import Policyholder   # Import Policyholder class
import os

# Print the list of files in the current working directory
# print("Files in current directory:", os.listdir())

# Create products
# Instantiate two insurance products
product1 = Product("P001", "Health Insurance", 6000)
product2 = Product("P002", "Life Insurance", 10000)

# Create policyholders
# Create two policyholder profiles
holder1 = Policyholder("Ayomide Ogunsiji", "PH001")
holder2 = Policyholder("Daniel Blake", "PH002")

# Create payments
# Create payments using today's date
payment1 = Payment("PH001", 6000, date.today())
payment2 = Payment("PH002", 10000, date.today())

# Assign products and payments
# Link product and payment to the first policyholder
holder1.add_policy(product1)
holder1.add_payment(payment1)

# Link product and payment to the second policyholder
holder2.add_policy(product2)
holder2.add_payment(payment2)

# Display details
# Print account summary (returns a dictionary)
print(holder1.get_details())
print(holder2.get_details())
