# Define the Payment class to manage payments related to policies
class Payment:
    def __init__(self, policy_id, amount, date):
        self.policy_id = policy_id
        self.amount = amount
        self.date = date
        self.status = "Paid"

# Add a penalty amount to the payment (e.g., for late payment)
    def add_penalty(self, penalty_amount):
        self.amount += penalty_amount

# Returns a reminder message for this payment
    def send_reminder(self):
        return f"Reminder: Payment of {self.amount} is due for policy {self.policy_id}."
