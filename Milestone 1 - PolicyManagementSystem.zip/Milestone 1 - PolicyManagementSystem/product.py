# Define the Product class to represent an insurance product
class Product:
    def __init__(self, product_id, product_name, premium):
        # product_id (str): Unique identifier for the product
        self.product_id = product_id
        # product_name (str): Name of the insurance product
        self.product_name = product_name
        # premium (float or int): Cost of the product
        self.premium = premium
        # Status could be 'Available' or 'Suspended'
        self.status = "Available"

# Update product details
    def update(self, new_name=None, new_premium=None):
        if new_name:
            self.product_name = new_name
        if new_premium:
            self.premium = new_premium

# Suspend the product so it cannot be selected or sold anymore
    def suspend(self):
        self.status = "Suspended"
